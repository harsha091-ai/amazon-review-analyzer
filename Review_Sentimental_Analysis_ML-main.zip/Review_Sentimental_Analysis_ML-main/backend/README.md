# Sentiment Analysis Backend API

FastAPI-based backend for Amazon Review Sentiment Analysis.

## Features

- 🚀 **Fast API endpoints** for sentiment analysis
- 🤖 **Neural Network + TextBlob** ensemble model
- 📊 **Batch processing** support
- 📁 **File upload** (CSV/TSV)
- 📈 **Statistics tracking**
- 🔄 **CORS enabled** for frontend integration

## Installation

1. **Create virtual environment:**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Download NLTK data (if needed):**
```python
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
```

## Running the API

```bash
python main.py
```

Or using uvicorn directly:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at: `http://localhost:8000`

## API Documentation

Once running, visit:
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

## API Endpoints

### Core Endpoints

- `GET /` - API information
- `GET /health` - Health check
- `POST /api/analyze` - Analyze single review
- `POST /api/batch-analyze` - Analyze multiple reviews
- `POST /api/upload` - Upload CSV/TSV file
- `GET /api/stats` - Get analysis statistics
- `GET /api/history` - Get analysis history
- `DELETE /api/history` - Clear history
- `GET /api/model-info` - Get model information

## Example Usage

### Single Review Analysis

```bash
curl -X POST "http://localhost:8000/api/analyze" \
  -H "Content-Type: application/json" \
  -d '{"review_text": "This product is amazing!"}'
```

### Batch Analysis

```bash
curl -X POST "http://localhost:8000/api/batch-analyze" \
  -H "Content-Type: application/json" \
  -d '{"reviews": ["Great product!", "Terrible experience", "It works fine"]}'
```

## Project Structure

```
backend/
├── main.py              # FastAPI application
├── models.py            # Pydantic models
├── ml_service.py        # ML service layer
├── requirements.txt     # Python dependencies
├── .env.example         # Environment variables template
└── README.md           # This file
```

## Model Files

The API expects these model files in the parent directory:
- `sentiment_nn_model.h5` - Neural network model
- `tfidf_vectorizer.pkl` - TF-IDF vectorizer

If models are not found, the API falls back to TextBlob-only mode.

## Environment Variables

Copy `.env.example` to `.env` and configure:

```env
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=True
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

## Testing

Test the API is working:

```bash
# Health check
curl http://localhost:8000/health

# Test analysis
curl -X POST http://localhost:8000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"review_text": "Love this product!"}'
```

## Error Handling

The API returns proper HTTP status codes:
- `200` - Success
- `400` - Bad request
- `500` - Server error

All errors include detailed messages in the response.

## CORS Configuration

The API is configured to accept requests from:
- `http://localhost:3000` (React default)
- `http://localhost:5173` (Vite default)

Modify in `main.py` if needed.
