from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class ReviewRequest(BaseModel):
    """Single review analysis request"""
    review_text: str = Field(..., description="The review text to analyze", min_length=1)


class ReviewResponse(BaseModel):
    """Single review analysis response"""
    model_config = ConfigDict(protected_namespaces=())
    
    review_text: str
    sentiment: str  # "positive" or "negative"
    confidence: float  # 0-1
    polarity: float  # -1 to 1
    subjectivity: float  # 0 to 1
    analysis_timestamp: str
    model_used: str


class BatchReviewRequest(BaseModel):
    """Batch review analysis request"""
    reviews: List[str] = Field(..., description="List of reviews to analyze")


class BatchReviewResponse(BaseModel):
    """Batch review analysis response"""
    results: List[ReviewResponse]
    total_analyzed: int
    positive_count: int
    negative_count: int
    average_confidence: float


class AnalysisStats(BaseModel):
    """Overall analysis statistics"""
    total_analyses: int
    positive_count: int
    negative_count: int
    average_confidence: float
    analyses_today: int


class ModelInfo(BaseModel):
    """ML Model information"""
    model_config = ConfigDict(protected_namespaces=())
    
    model_name: str
    model_version: str
    accuracy: float
    model_type: str
    last_trained: str
    features_used: List[str]
