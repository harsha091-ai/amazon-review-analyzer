import os
import re

import joblib
import nltk
import numpy as np
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.tokenize import word_tokenize
from textblob import TextBlob

# Lazy import for TensorFlow - only import when needed
TENSORFLOW_AVAILABLE = None
_load_model = None


class SentimentAnalyzer:
    """
    Sentiment Analysis service using Neural Network + TextBlob
    """
    
    def __init__(self):
        self.tfidf = None
        self.nn_model = None
        self.stemmer = PorterStemmer()
        self.lemmatizer = WordNetLemmatizer()
        self.model_loaded = False
        
        # Download NLTK resources in background (non-blocking)
        # Users can manually download if needed: python -m nltk.downloader punkt stopwords wordnet
        
        # Load models
        self._load_models()
    
    def _lazy_import_tensorflow(self):
        """Lazy import TensorFlow only when needed"""
        global TENSORFLOW_AVAILABLE, _load_model
        if TENSORFLOW_AVAILABLE is None:
            try:
                from tensorflow.keras.models import load_model as _lm  # type: ignore
                _load_model = _lm
                TENSORFLOW_AVAILABLE = True
                print("✓ TensorFlow imported successfully")
            except ImportError:
                TENSORFLOW_AVAILABLE = False
                print("⚠ TensorFlow not available")
        return TENSORFLOW_AVAILABLE
    
    def _load_models(self):
        """Load ML models from disk"""
        try:
            # Get parent directory path
            parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            tfidf_path = os.path.join(parent_dir, "tfidf_vectorizer.pkl")
            model_path = os.path.join(parent_dir, "sentiment_nn_model.h5")
            
            # Try to load TF-IDF vectorizer
            if os.path.exists(tfidf_path):
                self.tfidf = joblib.load(tfidf_path)
                print(f"✓ Loaded TF-IDF vectorizer from {tfidf_path}")
            else:
                print(f"⚠ TF-IDF vectorizer not found at {tfidf_path}")
            
            # Skip neural network model loading to avoid TensorFlow import issues
            # Model can be loaded on-demand if needed in the future
            print(f"⚠ Neural Network model loading skipped (TensorFlow import issues)")
            print("⚠ Running in TextBlob-only mode")
                
        except Exception as e:
            print(f"Error loading models: {str(e)}")
            print("⚠ Running in TextBlob-only mode")
    
    def preprocess_text(self, text, use_stemming=True, use_lemmatization=True):
        """
        Preprocess text for analysis
        """
        try:
            # Remove special characters and digits
            text = re.sub(r'[^\w\s]', '', text)
            text = re.sub(r'\d+', '', text)
            
            # Tokenize
            words = word_tokenize(text.lower())
            
            # Remove stopwords
            stop_words = set(stopwords.words('english'))
            words = [word for word in words if word not in stop_words]
            
            # Stemming
            if use_stemming:
                words = [self.stemmer.stem(word) for word in words]
            
            # Lemmatization
            if use_lemmatization:
                words = [self.lemmatizer.lemmatize(word) for word in words]
            
            return ' '.join(words)
        except Exception as e:
            print(f"Preprocessing error: {str(e)}")
            return text
    
    def analyze_single(self, review_text: str) -> dict:
        """
        Analyze sentiment of a single review
        
        Returns:
            dict with sentiment, confidence, polarity, subjectivity
        """
        try:
            # TextBlob analysis (always available)
            blob = TextBlob(review_text)
            polarity = blob.sentiment.polarity
            subjectivity = blob.sentiment.subjectivity
            
            # Default to TextBlob
            sentiment = "positive" if polarity > 0 else "negative" if polarity < 0 else "neutral"
            confidence = abs(polarity)
            model_used = "TextBlob"
            
            # Use Neural Network if available
            if self.model_loaded and self.tfidf and self.nn_model:
                try:
                    # Preprocess
                    cleaned_text = self.preprocess_text(review_text)
                    
                    # Vectorize
                    text_vec = self.tfidf.transform([cleaned_text])
                    
                    # Predict
                    nn_prob = self.nn_model.predict(text_vec.toarray(), verbose=0)[0][0]
                    nn_sentiment = "positive" if nn_prob > 0.5 else "negative"
                    
                    # Use neural network prediction
                    sentiment = nn_sentiment
                    confidence = float(nn_prob if nn_prob > 0.5 else 1 - nn_prob)
                    model_used = "Neural Network + TextBlob"
                    
                except Exception as e:
                    print(f"Neural network prediction failed: {str(e)}")
                    # Fall back to TextBlob
                    pass
            
            return {
                "sentiment": sentiment,
                "confidence": float(confidence),
                "polarity": float(polarity),
                "subjectivity": float(subjectivity),
                "model_used": model_used
            }
            
        except Exception as e:
            raise Exception(f"Analysis failed: {str(e)}")
    
    def is_loaded(self) -> bool:
        """Check if models are loaded"""
        return self.model_loaded or True  # TextBlob is always available


# Test the service
if __name__ == "__main__":
    analyzer = SentimentAnalyzer()
    
    # Test reviews
    test_reviews = [
        "This product is amazing! Works perfectly and exceeded my expectations.",
        "Terrible quality. Broke after 2 days. Very disappointed.",
        "It's okay for the price, nothing special but works as expected."
    ]
    
    print("\n" + "="*60)
    print("Testing Sentiment Analyzer")
    print("="*60)
    
    for review in test_reviews:
        result = analyzer.analyze_single(review)
        print(f"\nReview: {review}")
        print(f"Sentiment: {result['sentiment']} (confidence: {result['confidence']:.2%})")
        print(f"Polarity: {result['polarity']:.2f} | Subjectivity: {result['subjectivity']:.2f}")
        print(f"Model: {result['model_used']}")
