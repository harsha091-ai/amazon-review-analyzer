import io
from datetime import datetime
from typing import List, Optional

import uvicorn
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from ml_service import SentimentAnalyzer
from models import (AnalysisStats, BatchReviewRequest, BatchReviewResponse,
                    ModelInfo, ReviewRequest, ReviewResponse)
from pydantic import BaseModel

# Initialize FastAPI app
app = FastAPI(
    title="Amazon Review Sentiment Analysis API",
    description="AI-powered sentiment analysis for Amazon product reviews",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],  # React dev servers
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize ML service
sentiment_analyzer = SentimentAnalyzer()

# In-memory storage for demo (use a database in production)
analysis_history = []


@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Amazon Review Sentiment Analysis API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "health": "/health",
            "analyze": "/api/analyze",
            "batch_analyze": "/api/batch-analyze",
            "upload": "/api/upload",
            "stats": "/api/stats",
            "history": "/api/history",
            "model_info": "/api/model-info"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "model_loaded": sentiment_analyzer.is_loaded()
    }


@app.post("/api/analyze", response_model=ReviewResponse)
async def analyze_review(request: ReviewRequest):
    """
    Analyze sentiment of a single review
    """
    try:
        result = sentiment_analyzer.analyze_single(request.review_text)
        
        # Store in history
        analysis_history.append({
            "timestamp": datetime.now().isoformat(),
            "review": request.review_text,
            "sentiment": result["sentiment"],
            "confidence": result["confidence"]
        })
        
        return ReviewResponse(
            review_text=request.review_text,
            sentiment=result["sentiment"],
            confidence=result["confidence"],
            polarity=result["polarity"],
            subjectivity=result["subjectivity"],
            analysis_timestamp=datetime.now().isoformat(),
            model_used=result["model_used"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@app.post("/api/batch-analyze", response_model=BatchReviewResponse)
async def batch_analyze(request: BatchReviewRequest):
    """
    Analyze sentiment of multiple reviews
    """
    try:
        results = []
        for review in request.reviews:
            result = sentiment_analyzer.analyze_single(review)
            results.append(ReviewResponse(
                review_text=review,
                sentiment=result["sentiment"],
                confidence=result["confidence"],
                polarity=result["polarity"],
                subjectivity=result["subjectivity"],
                analysis_timestamp=datetime.now().isoformat(),
                model_used=result["model_used"]
            ))
            
            # Store in history
            analysis_history.append({
                "timestamp": datetime.now().isoformat(),
                "review": review,
                "sentiment": result["sentiment"],
                "confidence": result["confidence"]
            })
        
        # Calculate stats
        positive_count = sum(1 for r in results if r.sentiment == "positive")
        negative_count = sum(1 for r in results if r.sentiment == "negative")
        avg_confidence = sum(r.confidence for r in results) / len(results)
        
        return BatchReviewResponse(
            results=results,
            total_analyzed=len(results),
            positive_count=positive_count,
            negative_count=negative_count,
            average_confidence=avg_confidence
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Batch analysis failed: {str(e)}")


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    """
    Upload CSV/TSV file for batch analysis
    """
    try:
        # Read file
        contents = await file.read()
        content_str = contents.decode('utf-8')
        
        # Determine separator
        if file.filename.endswith('.tsv'):
            separator = '\t'
        elif file.filename.endswith('.csv'):
            separator = ','
        else:
            raise HTTPException(status_code=400, detail="Only CSV and TSV files are supported")
        
        # Parse file manually
        lines = content_str.strip().split('\n')
        if len(lines) < 2:
            raise HTTPException(status_code=400, detail="File must have at least a header and one data row")
        
        # Get headers
        headers = [h.strip().strip('"') for h in lines[0].split(separator)]
        
        # Find review column
        review_column_idx = None
        for idx, col in enumerate(headers):
            if col.lower() in ['verified_reviews', 'review', 'text', 'reviews']:
                review_column_idx = idx
                break
        
        if review_column_idx is None:
            raise HTTPException(
                status_code=400,
                detail=f"No review column found. Available columns: {headers}"
            )
        
        # Extract reviews (limit to 100)
        reviews = []
        for line in lines[1:101]:  # Skip header, max 100 reviews
            parts = line.split(separator)
            if len(parts) > review_column_idx:
                review = parts[review_column_idx].strip().strip('"')
                if review:
                    reviews.append(review)
        
        # Analyze reviews
        results = []
        for review in reviews:
            result = sentiment_analyzer.analyze_single(review)
            results.append({
                "review": review,
                "sentiment": result["sentiment"],
                "confidence": result["confidence"]
            })
        
        # Calculate stats
        positive_count = sum(1 for r in results if r["sentiment"] == "positive")
        negative_count = sum(1 for r in results if r["sentiment"] == "negative")
        
        return {
            "filename": file.filename,
            "total_reviews": len(results),
            "positive_count": positive_count,
            "negative_count": negative_count,
            "results": results[:20]  # Return first 20 for preview
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File processing failed: {str(e)}")


@app.get("/api/stats", response_model=AnalysisStats)
async def get_stats():
    """
    Get overall analysis statistics
    """
    if not analysis_history:
        return AnalysisStats(
            total_analyses=0,
            positive_count=0,
            negative_count=0,
            average_confidence=0.0,
            analyses_today=0
        )
    
    positive_count = sum(1 for a in analysis_history if a["sentiment"] == "positive")
    negative_count = sum(1 for a in analysis_history if a["sentiment"] == "negative")
    avg_confidence = sum(a["confidence"] for a in analysis_history) / len(analysis_history)
    
    # Count today's analyses
    today = datetime.now().date()
    analyses_today = sum(
        1 for a in analysis_history 
        if datetime.fromisoformat(a["timestamp"]).date() == today
    )
    
    return AnalysisStats(
        total_analyses=len(analysis_history),
        positive_count=positive_count,
        negative_count=negative_count,
        average_confidence=avg_confidence,
        analyses_today=analyses_today
    )


@app.get("/api/history")
async def get_history(limit: int = 10):
    """
    Get recent analysis history
    """
    return {
        "history": analysis_history[-limit:][::-1],  # Return last N, newest first
        "total": len(analysis_history)
    }


@app.get("/api/model-info", response_model=ModelInfo)
async def get_model_info():
    """
    Get information about the ML model
    """
    return ModelInfo(
        model_name="Neural Network + TextBlob Ensemble",
        model_version="1.0.0",
        accuracy=0.92,
        model_type="Deep Learning + Rule-based",
        last_trained="2026-02-01",
        features_used=["TF-IDF", "Polarity", "Subjectivity"]
    )


@app.delete("/api/history")
async def clear_history():
    """
    Clear analysis history
    """
    global analysis_history
    count = len(analysis_history)
    analysis_history = []
    return {"message": f"Cleared {count} analysis records"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
