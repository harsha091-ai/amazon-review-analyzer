# Quick Start Guide

Get the Sentiment Analysis application running in 5 minutes!

## Prerequisites Check

```bash
# Check Python version (need 3.8+)
python --version

# Check Node.js version (need 16+)
node --version

# Check npm
npm --version
```

## Step 1: Backend Setup (2 minutes)

```bash
# Navigate to project root
cd "Sentiment Analysis , Group 4"

# Go to backend
cd backend

# Create virtual environment
python -m venv venv

# Activate it
venv\Scripts\activate    # Windows
# source venv/bin/activate  # macOS/Linux

# Install dependencies (this may take a minute)
pip install -r requirements.txt

# Download NLTK data
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet'); nltk.download('punkt_tab')"
```

## Step 2: Start Backend (1 minute)

```bash
# Still in backend directory with venv activated
python main.py
```

✅ Backend running at **http://localhost:8000**

Keep this terminal open!

## Step 3: Frontend Setup (2 minutes)

Open a **NEW terminal**:

```bash
# Navigate to project root
cd "Sentiment Analysis , Group 4"

# Go to frontend
cd frontend

# Install dependencies
npm install
```

## Step 4: Start Frontend (30 seconds)

```bash
# Still in frontend directory
npm run dev
```

✅ Frontend running at **http://localhost:3000**

## Step 5: Open and Test

1. **Open browser:** http://localhost:3000
2. **Click "Launch Dashboard"**
3. **Try a sample review:**
   - Click a sample review or type your own
   - Click "Analyze Sentiment"
   - See the results!

## 🎉 You're Done!

### What to try:

- ✅ **Single Analysis:** Analyze individual reviews
- ✅ **Batch Analysis:** Process multiple reviews at once
- ✅ **File Upload:** Upload CSV/TSV files
- ✅ **View History:** See all your analyses

## Quick Troubleshooting

### Backend won't start?

```bash
# Make sure you're in the backend directory
cd backend

# Virtual environment activated?
venv\Scripts\activate

# Try reinstalling
pip install -r requirements.txt
```

### Frontend won't start?

```bash
# Make sure you're in the frontend directory
cd frontend

# Try cleaning and reinstalling
rm -rf node_modules
npm install
```

### Can't connect to API?

1. Check backend is running (Terminal 1)
2. Check it says "Running on http://0.0.0.0:8000"
3. Visit http://localhost:8000/health in browser
4. Should see: `{"status":"healthy",...}`

## Need Help?

1. Check the main [README.md](README.md)
2. Check [backend/README.md](backend/README.md)
3. Check [frontend/README.md](frontend/README.md)

## Testing with Sample Data

Want to upload a file? Use the included `amazon2.tsv`:

1. Go to Dashboard
2. Click "File Upload" tab
3. Drag and drop `amazon2.tsv`
4. See the magic happen!

---

**Happy Analyzing! 🚀**
