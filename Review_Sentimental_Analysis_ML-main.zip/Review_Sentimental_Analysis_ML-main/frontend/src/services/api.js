import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const sentimentAPI = {
  // Analyze single review
  analyzeSingle: async (reviewText) => {
    const response = await api.post('/api/analyze', { review_text: reviewText });
    return response.data;
  },

  // Batch analyze reviews
  batchAnalyze: async (reviews) => {
    const response = await api.post('/api/batch-analyze', { reviews });
    return response.data;
  },

  // Upload file
  uploadFile: async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await api.post('/api/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  // Get statistics
  getStats: async () => {
    const response = await api.get('/api/stats');
    return response.data;
  },

  // Get history
  getHistory: async (limit = 10) => {
    const response = await api.get(`/api/history?limit=${limit}`);
    return response.data;
  },

  // Clear history
  clearHistory: async () => {
    const response = await api.delete('/api/history');
    return response.data;
  },

  // Get model info
  getModelInfo: async () => {
    const response = await api.get('/api/model-info');
    return response.data;
  },

  // Health check
  healthCheck: async () => {
    const response = await api.get('/health');
    return response.data;
  },
};

export default api;
