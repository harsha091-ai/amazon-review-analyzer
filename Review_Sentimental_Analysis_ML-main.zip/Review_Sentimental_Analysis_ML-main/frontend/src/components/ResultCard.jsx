import { motion } from 'framer-motion';
import { FaSmile, FaFrown, FaMeh, FaChartLine, FaBrain } from 'react-icons/fa';

const ResultCard = ({ result }) => {
  const isPositive = result.sentiment === 'positive';
  const isNegative = result.sentiment === 'negative';
  const isNeutral = result.sentiment === 'neutral';

  const sentimentConfig = {
    positive: {
      color: 'bg-neo-green',
      icon: <FaSmile className="text-6xl" />,
      emoji: '😊',
      label: 'POSITIVE'
    },
    negative: {
      color: 'bg-neo-red',
      icon: <FaFrown className="text-6xl" />,
      emoji: '😞',
      label: 'NEGATIVE'
    },
    neutral: {
      color: 'bg-neo-blue',
      icon: <FaMeh className="text-6xl" />,
      emoji: '😐',
      label: 'NEUTRAL'
    }
  };

  const config = sentimentConfig[result.sentiment] || sentimentConfig.neutral;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="neo-card"
    >
      <h2 className="text-3xl font-black mb-6">Analysis Result</h2>

      {/* Sentiment Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`${config.color} text-white p-6 border-4 border-black shadow-neo mb-6`}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-bold uppercase mb-2">Sentiment</div>
            <div className="text-4xl font-black">{config.label}</div>
          </div>
          <div className="text-6xl">{config.emoji}</div>
        </div>
      </motion.div>

      {/* Review Text */}
      <div className="mb-6 p-4 bg-gray-50 border-4 border-black">
        <div className="text-sm font-bold uppercase mb-2">Review</div>
        <p className="text-gray-800 italic">"{result.review_text}"</p>
      </div>

      {/* Metrics */}
      <div className="space-y-4">
        {/* Confidence */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold uppercase text-sm">Confidence</span>
            <span className="text-2xl font-black">{(result.confidence * 100).toFixed(1)}%</span>
          </div>
          <div className="h-6 bg-gray-200 border-4 border-black overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${result.confidence * 100}%` }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className={`h-full ${config.color}`}
            />
          </div>
        </div>

        {/* Polarity */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold uppercase text-sm">Polarity</span>
            <span className="text-2xl font-black">{result.polarity.toFixed(2)}</span>
          </div>
          <div className="h-6 bg-gray-200 border-4 border-black overflow-hidden">
            <motion.div
              initial={{ width: '50%' }}
              animate={{ width: `${(result.polarity + 1) * 50}%` }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="h-full bg-neo-blue"
            />
          </div>
          <div className="flex justify-between text-xs font-bold mt-1">
            <span>-1.0 (Negative)</span>
            <span>+1.0 (Positive)</span>
          </div>
        </div>

        {/* Subjectivity */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold uppercase text-sm">Subjectivity</span>
            <span className="text-2xl font-black">{result.subjectivity.toFixed(2)}</span>
          </div>
          <div className="h-6 bg-gray-200 border-4 border-black overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${result.subjectivity * 100}%` }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="h-full bg-neo-yellow"
            />
          </div>
          <div className="flex justify-between text-xs font-bold mt-1">
            <span>0.0 (Objective)</span>
            <span>1.0 (Subjective)</span>
          </div>
        </div>
      </div>

      {/* Meta Info */}
      <div className="mt-6 pt-6 border-t-4 border-black">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <FaBrain className="text-neo-purple" />
            <span className="font-bold">{result.model_used}</span>
          </div>
          <div className="text-gray-600">
            {new Date(result.analysis_timestamp).toLocaleTimeString()}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ResultCard;
