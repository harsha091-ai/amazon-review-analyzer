import { useState } from 'react';
import { motion } from 'framer-motion';
import { FaList, FaPlus, FaTrash, FaSpinner } from 'react-icons/fa';
import { sentimentAPI } from '../services/api';

const BatchAnalysis = ({ onAnalysisComplete }) => {
  const [reviews, setReviews] = useState(['']);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const addReview = () => {
    setReviews([...reviews, '']);
  };

  const removeReview = (index) => {
    setReviews(reviews.filter((_, i) => i !== index));
  };

  const updateReview = (index, value) => {
    const newReviews = [...reviews];
    newReviews[index] = value;
    setReviews(newReviews);
  };

  const handleAnalyze = async () => {
    const validReviews = reviews.filter(r => r.trim());
    
    if (validReviews.length === 0) {
      setError('Please enter at least one review');
      return;
    }

    setLoading(true);
    setError(null);
    setResults(null);

    try {
      const data = await sentimentAPI.batchAnalyze(validReviews);
      setResults(data);
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (err) {
      setError(err.response?.data?.detail || 'Batch analysis failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="neo-card"
      >
        <h2 className="text-3xl font-black mb-6 flex items-center gap-3">
          <span className="bg-neo-blue text-white p-2 border-4 border-black shadow-neo-sm">
            <FaList />
          </span>
          Batch Analysis
        </h2>

        <div className="space-y-4 mb-6 max-h-96 overflow-y-auto pr-2">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-2"
            >
              <textarea
                value={review}
                onChange={(e) => updateReview(index, e.target.value)}
                placeholder={`Review ${index + 1}...`}
                rows={2}
                className="neo-input flex-1 resize-none text-sm"
              />
              {reviews.length > 1 && (
                <motion.button
                  onClick={() => removeReview(index)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="neo-button bg-neo-red text-white px-3"
                >
                  <FaTrash />
                </motion.button>
              )}
            </motion.div>
          ))}
        </div>

        <div className="flex gap-3">
          <motion.button
            onClick={addReview}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="neo-button bg-white flex-1"
          >
            <FaPlus className="inline-block mr-2" />
            Add Review
          </motion.button>

          <motion.button
            onClick={handleAnalyze}
            disabled={loading}
            whileHover={{ scale: loading ? 1 : 1.03 }}
            whileTap={{ scale: loading ? 1 : 0.97 }}
            className={`neo-button flex-1 ${
              loading ? 'bg-gray-300' : 'bg-neo-blue text-white'
            }`}
          >
            {loading ? (
              <>
                <FaSpinner className="inline-block animate-spin mr-2" />
                Analyzing...
              </>
            ) : (
              'Analyze All'
            )}
          </motion.button>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 bg-neo-red text-white px-4 py-3 border-4 border-black shadow-neo-sm font-bold"
          >
            {error}
          </motion.div>
        )}
      </motion.div>

      {/* Results Section */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="neo-card"
      >
        {results ? (
          <>
            <h3 className="text-3xl font-black mb-6">Results</h3>

            {/* Summary */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="bg-neo-blue text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{results.total_analyzed}</div>
                <div className="text-sm font-bold uppercase">Total</div>
              </div>
              <div className="bg-neo-green text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{results.positive_count}</div>
                <div className="text-sm font-bold uppercase">Positive</div>
              </div>
              <div className="bg-neo-red text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{results.negative_count}</div>
                <div className="text-sm font-bold uppercase">Negative</div>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex justify-between font-bold mb-2">
                <span>Average Confidence</span>
                <span className="text-xl">{(results.average_confidence * 100).toFixed(1)}%</span>
              </div>
              <div className="h-6 bg-gray-200 border-4 border-black">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${results.average_confidence * 100}%` }}
                  className="h-full bg-neo-purple"
                />
              </div>
            </div>

            {/* Individual Results */}
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {results.results.map((result, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-3 border-4 border-black ${
                    result.sentiment === 'positive' ? 'bg-neo-green/20' : 'bg-neo-red/20'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="neo-badge text-xs bg-white">
                      #{index + 1}
                    </span>
                    <span className={`neo-badge text-xs ${
                      result.sentiment === 'positive' 
                        ? 'bg-neo-green text-white' 
                        : 'bg-neo-red text-white'
                    }`}>
                      {result.sentiment.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm mb-2 line-clamp-2">{result.review_text}</p>
                  <div className="text-xs font-bold">
                    Confidence: {(result.confidence * 100).toFixed(1)}%
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-12">
            <div className="text-8xl mb-6">📊</div>
            <h3 className="text-2xl font-black mb-3">Batch Analysis Ready</h3>
            <p className="text-gray-600 font-medium">
              Add multiple reviews and analyze them all at once
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default BatchAnalysis;
