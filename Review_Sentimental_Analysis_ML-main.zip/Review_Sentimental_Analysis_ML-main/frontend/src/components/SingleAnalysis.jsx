import { useState } from 'react';
import { motion } from 'framer-motion';
import { FaSearch, FaSpinner } from 'react-icons/fa';
import { sentimentAPI } from '../services/api';
import ResultCard from './ResultCard';

const SingleAnalysis = ({ onAnalysisComplete }) => {
  const [reviewText, setReviewText] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAnalyze = async () => {
    if (!reviewText.trim()) {
      setError('Please enter a review to analyze');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await sentimentAPI.analyzeSingle(reviewText);
      setResult(data);
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (err) {
      setError(err.response?.data?.detail || 'Analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const sampleReviews = [
    "This product is absolutely amazing! Best purchase I've made this year.",
    "Terrible quality. Stopped working after 2 days. Very disappointed.",
    "It's okay for the price. Nothing special but works as expected."
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="neo-card"
      >
        <h2 className="text-3xl font-black mb-6 flex items-center gap-3">
          <span className="bg-neo-purple text-white p-2 border-4 border-black shadow-neo-sm">
            <FaSearch />
          </span>
          Analyze Review
        </h2>

        <div className="mb-6">
          <label className="block font-bold mb-3 uppercase text-sm">
            Enter Review Text
          </label>
          <textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Type or paste your Amazon review here..."
            rows={8}
            className="neo-input w-full resize-none"
          />
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-neo-red text-white px-4 py-3 border-4 border-black shadow-neo-sm mb-4 font-bold"
          >
            {error}
          </motion.div>
        )}

        <motion.button
          onClick={handleAnalyze}
          disabled={loading}
          whileHover={{ scale: loading ? 1 : 1.03 }}
          whileTap={{ scale: loading ? 1 : 0.97 }}
          className={`neo-button w-full ${
            loading ? 'bg-gray-300' : 'bg-neo-purple text-white'
          }`}
        >
          {loading ? (
            <>
              <FaSpinner className="inline-block animate-spin mr-2" />
              Analyzing...
            </>
          ) : (
            <>
              <FaSearch className="inline-block mr-2" />
              Analyze Sentiment
            </>
          )}
        </motion.button>

        {/* Sample Reviews */}
        <div className="mt-8">
          <p className="font-bold mb-3 uppercase text-sm">Quick Try:</p>
          <div className="space-y-2">
            {sampleReviews.map((sample, index) => (
              <motion.button
                key={index}
                onClick={() => setReviewText(sample)}
                whileHover={{ scale: 1.02 }}
                className="text-left w-full p-3 border-2 border-black hover:shadow-neo-sm transition-all text-sm"
              >
                {sample}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Result Section */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
      >
        {result ? (
          <ResultCard result={result} />
        ) : (
          <div className="neo-card h-full flex flex-col items-center justify-center text-center p-12 bg-gray-50">
            <div className="text-8xl mb-6">🤖</div>
            <h3 className="text-2xl font-black mb-3">Ready to Analyze</h3>
            <p className="text-gray-600 font-medium">
              Enter a review and click analyze to get instant sentiment insights
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default SingleAnalysis;
