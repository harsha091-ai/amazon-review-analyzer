import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { FaUpload, FaSpinner, FaFileAlt, FaCheckCircle } from 'react-icons/fa';
import { sentimentAPI } from '../services/api';

const FileUpload = ({ onUploadComplete }) => {
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const onDrop = useCallback(async (acceptedFiles) => {
    if (acceptedFiles.length === 0) return;

    const file = acceptedFiles[0];
    setUploading(true);
    setError(null);
    setResult(null);

    try {
      const data = await sentimentAPI.uploadFile(file);
      setResult(data);
      if (onUploadComplete) onUploadComplete();
    } catch (err) {
      setError(err.response?.data?.detail || 'File upload failed');
    } finally {
      setUploading(false);
    }
  }, [onUploadComplete]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'text/tab-separated-values': ['.tsv']
    },
    maxFiles: 1
  });

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Upload Section */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="neo-card"
      >
        <h2 className="text-3xl font-black mb-6 flex items-center gap-3">
          <span className="bg-neo-orange text-white p-2 border-4 border-black shadow-neo-sm">
            <FaUpload />
          </span>
          Upload File
        </h2>

        <div
          {...getRootProps()}
          className={`border-4 border-dashed border-black p-12 text-center cursor-pointer transition-all ${
            isDragActive 
              ? 'bg-neo-yellow/30 shadow-neo' 
              : 'bg-gray-50 hover:bg-gray-100'
          }`}
        >
          <input {...getInputProps()} />
          
          {uploading ? (
            <div>
              <FaSpinner className="text-6xl mx-auto animate-spin text-neo-purple mb-4" />
              <p className="font-bold">Uploading and analyzing...</p>
            </div>
          ) : (
            <div>
              <FaFileAlt className="text-6xl mx-auto mb-4 text-gray-400" />
              {isDragActive ? (
                <p className="text-xl font-bold">Drop the file here...</p>
              ) : (
                <>
                  <p className="text-xl font-bold mb-2">
                    Drag & drop a CSV or TSV file here
                  </p>
                  <p className="text-gray-600 font-medium mb-4">or click to browse</p>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="neo-button bg-neo-orange text-white"
                  >
                    Select File
                  </motion.button>
                </>
              )}
            </div>
          )}
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 bg-neo-red text-white px-4 py-3 border-4 border-black shadow-neo-sm font-bold"
          >
            {error}
          </motion.div>
        )}

        {/* Instructions */}
        <div className="mt-6 p-4 bg-neo-blue/10 border-4 border-black">
          <h3 className="font-black uppercase mb-3">File Requirements:</h3>
          <ul className="space-y-2 text-sm font-medium">
            <li className="flex items-start gap-2">
              <FaCheckCircle className="text-neo-green mt-1 flex-shrink-0" />
              <span>CSV or TSV format</span>
            </li>
            <li className="flex items-start gap-2">
              <FaCheckCircle className="text-neo-green mt-1 flex-shrink-0" />
              <span>Must contain a review column (verified_reviews, review, text, or reviews)</span>
            </li>
            <li className="flex items-start gap-2">
              <FaCheckCircle className="text-neo-green mt-1 flex-shrink-0" />
              <span>Maximum 100 reviews will be processed</span>
            </li>
            <li className="flex items-start gap-2">
              <FaCheckCircle className="text-neo-green mt-1 flex-shrink-0" />
              <span>Each row should contain one review</span>
            </li>
          </ul>
        </div>
      </motion.div>

      {/* Results Section */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="neo-card"
      >
        {result ? (
          <>
            <h3 className="text-3xl font-black mb-6">Upload Results</h3>

            {/* Summary */}
            <div className="mb-6 p-4 bg-neo-green/20 border-4 border-black">
              <div className="flex items-center gap-3 mb-3">
                <FaCheckCircle className="text-3xl text-neo-green" />
                <div>
                  <div className="font-black text-xl">File Processed!</div>
                  <div className="text-sm font-bold text-gray-600">{result.filename}</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="bg-neo-blue text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{result.total_reviews}</div>
                <div className="text-sm font-bold uppercase">Total</div>
              </div>
              <div className="bg-neo-green text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{result.positive_count}</div>
                <div className="text-sm font-bold uppercase">Positive</div>
              </div>
              <div className="bg-neo-red text-white p-4 border-4 border-black shadow-neo-sm">
                <div className="text-3xl font-black">{result.negative_count}</div>
                <div className="text-sm font-bold uppercase">Negative</div>
              </div>
            </div>

            {/* Preview Results */}
            <h4 className="font-black uppercase mb-3">Preview (First 20 Results):</h4>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {result.results?.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className={`p-3 border-4 border-black ${
                    item.sentiment === 'positive' ? 'bg-neo-green/20' : 'bg-neo-red/20'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="neo-badge text-xs bg-white">
                      #{index + 1}
                    </span>
                    <span className={`neo-badge text-xs ${
                      item.sentiment === 'positive' 
                        ? 'bg-neo-green text-white' 
                        : 'bg-neo-red text-white'
                    }`}>
                      {item.sentiment.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm mb-2 line-clamp-2">{item.review}</p>
                  <div className="text-xs font-bold">
                    Confidence: {(item.confidence * 100).toFixed(1)}%
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-12">
            <div className="text-8xl mb-6">📁</div>
            <h3 className="text-2xl font-black mb-3">Ready to Upload</h3>
            <p className="text-gray-600 font-medium">
              Upload a CSV or TSV file with reviews to analyze in bulk
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default FileUpload;
