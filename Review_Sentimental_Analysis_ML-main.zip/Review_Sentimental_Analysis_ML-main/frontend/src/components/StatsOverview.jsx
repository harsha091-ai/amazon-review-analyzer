import { motion } from 'framer-motion';
import { FaChartLine, FaSmile, FaFrown, FaSpinner } from 'react-icons/fa';

const StatsOverview = ({ stats, loading }) => {
  if (loading) {
    return (
      <div className="neo-card mb-8 text-center py-12">
        <FaSpinner className="inline-block text-4xl animate-spin text-neo-purple" />
        <p className="mt-4 font-bold">Loading statistics...</p>
      </div>
    );
  }

  const statCards = [
    {
      label: 'Total Analyses',
      value: stats?.total_analyses || 0,
      icon: <FaChartLine className="text-3xl" />,
      color: 'bg-neo-blue',
      textColor: 'text-white'
    },
    {
      label: 'Positive Reviews',
      value: stats?.positive_count || 0,
      icon: <FaSmile className="text-3xl" />,
      color: 'bg-neo-green',
      textColor: 'text-white'
    },
    {
      label: 'Negative Reviews',
      value: stats?.negative_count || 0,
      icon: <FaFrown className="text-3xl" />,
      color: 'bg-neo-red',
      textColor: 'text-white'
    },
    {
      label: 'Avg Confidence',
      value: `${((stats?.average_confidence || 0) * 100).toFixed(1)}%`,
      icon: <div className="text-3xl font-black">📊</div>,
      color: 'bg-neo-yellow',
      textColor: 'text-black'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((card, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          whileHover={{ y: -5 }}
          className={`neo-card ${card.color} ${card.textColor}`}
        >
          <div className="flex items-center justify-between mb-4">
            {card.icon}
            <div className="text-right">
              <div className="text-4xl font-black">{card.value}</div>
            </div>
          </div>
          <div className="font-bold uppercase text-sm">{card.label}</div>
        </motion.div>
      ))}
    </div>
  );
};

export default StatsOverview;
