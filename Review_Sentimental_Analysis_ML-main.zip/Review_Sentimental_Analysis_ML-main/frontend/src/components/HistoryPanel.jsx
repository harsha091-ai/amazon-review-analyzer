import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaHistory, FaTrash, FaSpinner } from 'react-icons/fa';
import { sentimentAPI } from '../services/api';

const HistoryPanel = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      setLoading(true);
      const data = await sentimentAPI.getHistory(50);
      setHistory(data.history);
      setError(null);
    } catch (err) {
      setError('Failed to load history');
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm('Are you sure you want to clear all history?')) return;

    try {
      await sentimentAPI.clearHistory();
      setHistory([]);
    } catch (err) {
      setError('Failed to clear history');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="neo-card"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-black flex items-center gap-3">
          <span className="bg-neo-purple text-white p-2 border-4 border-black shadow-neo-sm">
            <FaHistory />
          </span>
          Analysis History
        </h2>

        {history.length > 0 && (
          <motion.button
            onClick={handleClearHistory}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="neo-button bg-neo-red text-white"
          >
            <FaTrash className="inline-block mr-2" />
            Clear All
          </motion.button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12">
          <FaSpinner className="inline-block text-4xl animate-spin text-neo-purple" />
          <p className="mt-4 font-bold">Loading history...</p>
        </div>
      ) : error ? (
        <div className="bg-neo-red text-white px-4 py-3 border-4 border-black shadow-neo-sm font-bold">
          {error}
        </div>
      ) : history.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-8xl mb-6">📋</div>
          <h3 className="text-2xl font-black mb-3">No History Yet</h3>
          <p className="text-gray-600 font-medium">
            Your analysis history will appear here
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
          {history.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.03 }}
              className={`p-4 border-4 border-black ${
                item.sentiment === 'positive' 
                  ? 'bg-neo-green/10' 
                  : 'bg-neo-red/10'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <span className={`neo-badge ${
                  item.sentiment === 'positive' 
                    ? 'bg-neo-green text-white' 
                    : 'bg-neo-red text-white'
                }`}>
                  {item.sentiment.toUpperCase()} {
                    item.sentiment === 'positive' ? '😊' : '😞'
                  }
                </span>
                <span className="text-xs font-bold text-gray-600">
                  {new Date(item.timestamp).toLocaleString()}
                </span>
              </div>

              <p className="text-sm mb-3 italic">"{item.review}"</p>

              <div className="flex items-center gap-4 text-sm">
                <div>
                  <span className="font-bold">Confidence: </span>
                  <span className="font-black">{(item.confidence * 100).toFixed(1)}%</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default HistoryPanel;
