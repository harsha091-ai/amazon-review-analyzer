import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  FaHome,
  FaChartBar, 
  FaHistory,
  FaUpload,
  FaCog,
  FaAmazon,
  FaSmile,
  FaFrown,
  FaChartLine
} from 'react-icons/fa';

import SingleAnalysis from '../components/SingleAnalysis';
import BatchAnalysis from '../components/BatchAnalysis';
import FileUpload from '../components/FileUpload';
import StatsOverview from '../components/StatsOverview';
import HistoryPanel from '../components/HistoryPanel';
import { sentimentAPI } from '../services/api';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('single');
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [apiStatus, setApiStatus] = useState('checking');

  useEffect(() => {
    checkAPIHealth();
    loadStats();
    // Refresh stats every 30 seconds
    const interval = setInterval(loadStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const checkAPIHealth = async () => {
    try {
      await sentimentAPI.healthCheck();
      setApiStatus('connected');
    } catch (error) {
      setApiStatus('disconnected');
      console.error('API health check failed:', error);
    }
  };

  const loadStats = async () => {
    try {
      const data = await sentimentAPI.getStats();
      setStats(data);
      setLoading(false);
    } catch (error) {
      console.error('Failed to load stats:', error);
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'single', label: 'Single Review', icon: <FaChartBar /> },
    { id: 'batch', label: 'Batch Analysis', icon: <FaChartLine /> },
    { id: 'upload', label: 'File Upload', icon: <FaUpload /> },
    { id: 'history', label: 'History', icon: <FaHistory /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b-4 border-black shadow-neo-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center gap-3">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="bg-neo-pink p-3 border-4 border-black shadow-neo-sm"
              >
                <FaAmazon className="text-2xl text-white" />
              </motion.div>
              <div>
                <div className="text-2xl font-black uppercase">SentiMind</div>
                <div className="text-xs font-bold text-gray-600">AI DASHBOARD</div>
              </div>
            </Link>

            <div className="flex items-center gap-4">
              {/* API Status */}
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full border-2 border-black ${
                  apiStatus === 'connected' ? 'bg-neo-green' : 
                  apiStatus === 'disconnected' ? 'bg-neo-red' : 
                  'bg-neo-yellow'
                }`} />
                <span className="font-bold text-sm uppercase">
                  {apiStatus === 'connected' ? 'API Connected' : 
                   apiStatus === 'disconnected' ? 'API Offline' : 
                   'Checking...'}
                </span>
              </div>

              <Link to="/">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="neo-button bg-white px-4 py-2"
                >
                  <FaHome className="inline mr-2" />
                  Home
                </motion.button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Stats Overview */}
        <StatsOverview stats={stats} loading={loading} />

        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="flex gap-3 overflow-x-auto pb-2">
            {tabs.map((tab) => (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className={`neo-button px-6 py-3 whitespace-nowrap flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'bg-neo-purple text-white'
                    : 'bg-white'
                }`}
              >
                {tab.icon}
                {tab.label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {activeTab === 'single' && <SingleAnalysis onAnalysisComplete={loadStats} />}
          {activeTab === 'batch' && <BatchAnalysis onAnalysisComplete={loadStats} />}
          {activeTab === 'upload' && <FileUpload onUploadComplete={loadStats} />}
          {activeTab === 'history' && <HistoryPanel />}
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t-4 border-black mt-20">
        <div className="container mx-auto px-6 py-6 text-center">
          <p className="font-bold text-gray-700">
            Powered by Neural Networks & TextBlob | © 2026 SentiMind
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
