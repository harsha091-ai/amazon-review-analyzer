import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  FaBrain, 
  FaChartLine, 
  FaRocket, 
  FaShieldAlt,
  FaStar,
  FaAmazon
} from 'react-icons/fa';

const LandingPage = () => {
  const features = [
    {
      icon: <FaBrain className="text-5xl" />,
      title: "AI-Powered Analysis",
      description: "Neural Network + TextBlob ensemble for accurate sentiment detection",
      color: "bg-neo-purple"
    },
    {
      icon: <FaChartLine className="text-5xl" />,
      title: "Real-Time Insights",
      description: "Get instant sentiment analysis with confidence scores",
      color: "bg-neo-blue"
    },
    {
      icon: <FaRocket className="text-5xl" />,
      title: "Batch Processing",
      description: "Upload CSV/TSV files and analyze thousands of reviews",
      color: "bg-neo-green"
    },
    {
      icon: <FaShieldAlt className="text-5xl" />,
      title: "92% Accuracy",
      description: "Trained on Amazon reviews with proven reliability",
      color: "bg-neo-yellow"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="container mx-auto px-6 py-12"
      >
        {/* Header */}
        <header className="flex justify-between items-center mb-20">
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.05 }}
          >
            <div className="bg-neo-pink p-3 border-4 border-black shadow-neo">
              <FaAmazon className="text-3xl text-white" />
            </div>
            <span className="text-2xl font-black uppercase">SentiMind</span>
          </motion.div>
          
          <Link to="/dashboard">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="neo-button bg-neo-pink text-white"
            >
              Launch Dashboard
            </motion.button>
          </Link>
        </header>

        {/* Hero Content */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-block mb-6"
            >
              <span className="neo-badge bg-neo-yellow">
                🚀 AI-Powered
              </span>
            </motion.div>
            
            <h1 className="text-7xl font-black mb-6 leading-tight">
              Analyze Review
              <br />
              <span className="text-neo-purple">Sentiment</span>
              <br />
              Instantly
            </h1>
            
            <p className="text-xl text-gray-700 mb-8 leading-relaxed">
              Unlock the power of AI to understand customer emotions. 
              Get instant insights from Amazon product reviews with our 
              advanced sentiment analysis engine.
            </p>
            
            <div className="flex gap-4">
              <Link to="/dashboard">
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="neo-button bg-neo-purple text-white text-lg"
                >
                  Get Started Free
                </motion.button>
              </Link>
              
              <motion.button
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="neo-button bg-white text-black text-lg"
              >
                Watch Demo
              </motion.button>
            </div>
            
            <div className="flex items-center gap-8 mt-10">
              <div>
                <div className="text-4xl font-black text-neo-purple">92%</div>
                <div className="text-sm font-bold uppercase">Accuracy</div>
              </div>
              <div>
                <div className="text-4xl font-black text-neo-blue">3K+</div>
                <div className="text-sm font-bold uppercase">Reviews Analyzed</div>
              </div>
              <div>
                <div className="text-4xl font-black text-neo-green">{'< 1s'}</div>
                <div className="text-sm font-bold uppercase">Response Time</div>
              </div>
            </div>
          </motion.div>

          {/* Hero Visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="relative"
          >
            <div className="neo-card bg-gradient-to-br from-neo-pink to-neo-purple text-white">
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <FaStar className="text-yellow-300" />
                  <FaStar className="text-yellow-300" />
                  <FaStar className="text-yellow-300" />
                  <FaStar className="text-yellow-300" />
                  <FaStar className="text-yellow-300" />
                </div>
                <p className="text-lg italic">
                  "This product is absolutely amazing! Best purchase I've made this year. 
                  Highly recommended!"
                </p>
              </div>
              
              <div className="border-t-4 border-white/30 pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold">Sentiment</span>
                  <span className="neo-badge bg-neo-green border-white">
                    POSITIVE 😊
                  </span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold">Confidence</span>
                  <span className="text-2xl font-black">94.7%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-bold">Polarity</span>
                  <span className="text-2xl font-black">+0.85</span>
                </div>
              </div>
            </div>
            
            {/* Floating elements */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 3 }}
              className="absolute -top-6 -right-6 bg-neo-yellow p-4 border-4 border-black shadow-neo"
            >
              <FaBrain className="text-4xl" />
            </motion.div>
            
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2.5 }}
              className="absolute -bottom-6 -left-6 bg-neo-blue p-4 border-4 border-black shadow-neo text-white"
            >
              <FaChartLine className="text-4xl" />
            </motion.div>
          </motion.div>
        </div>

        {/* Features Section */}
        <div className="mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-black mb-4">
              Powerful Features
            </h2>
            <p className="text-xl text-gray-600">
              Everything you need for comprehensive sentiment analysis
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="neo-card hover:shadow-neo-hover"
              >
                <div className={`${feature.color} w-16 h-16 flex items-center justify-center border-4 border-black shadow-neo-sm mb-4`}>
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-black mb-3">{feature.title}</h3>
                <p className="text-gray-700">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="neo-card bg-gradient-to-r from-neo-purple to-neo-pink text-white text-center py-16"
        >
          <h2 className="text-5xl font-black mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Start analyzing customer sentiment today. No credit card required.
          </p>
          <Link to="/dashboard">
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="neo-button bg-neo-yellow text-black text-xl"
            >
              Launch Dashboard Now
            </motion.button>
          </Link>
        </motion.div>

        {/* Footer */}
        <footer className="mt-20 text-center text-gray-600">
          <p className="font-bold">
            © 2026 SentiMind - AI Sentiment Analysis Platform
          </p>
          <p className="mt-2">
            Powered by Neural Networks & TextBlob
          </p>
        </footer>
      </motion.div>
    </div>
  );
};

export default LandingPage;
