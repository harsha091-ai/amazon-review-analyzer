# Sentiment Analysis Frontend

React-based frontend with colorful Neobrutalism design for Amazon Review Sentiment Analysis.

## Features

- 🎨 **Neobrutalism Design** - Bold colors, thick borders, and shadows
- 🚀 **Single Review Analysis** - Instant sentiment detection
- 📊 **Batch Processing** - Analyze multiple reviews at once
- 📁 **File Upload** - CSV/TSV bulk analysis
- 📈 **Statistics Dashboard** - Real-time analytics
- 📜 **Analysis History** - Track all your analyses
- 🎭 **Smooth Animations** - Framer Motion powered

## Tech Stack

- **React 18** - UI library
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **React Router** - Navigation
- **Axios** - API calls
- **React Icons** - Icon library
- **Recharts** - Data visualization
- **React Dropzone** - File uploads

## Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Configure API endpoint:**
The API is configured in `src/services/api.js`. Default: `http://localhost:8000`

## Running the App

```bash
npm run dev
```

The app will be available at: `http://localhost:3000`

## Building for Production

```bash
npm run build
```

Build output will be in the `dist/` directory.

## Project Structure

```
frontend/
├── src/
│   ├── components/          # React components
│   │   ├── SingleAnalysis.jsx
│   │   ├── BatchAnalysis.jsx
│   │   ├── FileUpload.jsx
│   │   ├── ResultCard.jsx
│   │   ├── StatsOverview.jsx
│   │   └── HistoryPanel.jsx
│   ├── pages/              # Page components
│   │   ├── LandingPage.jsx
│   │   └── Dashboard.jsx
│   ├── services/           # API services
│   │   └── api.js
│   ├── App.jsx            # Main app component
│   ├── main.jsx           # Entry point
│   └── index.css          # Global styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── README.md
```

## Pages

### Landing Page (`/`)
- Hero section with product showcase
- Feature highlights
- Call-to-action
- Animated elements

### Dashboard (`/dashboard`)
- Statistics overview
- Single review analysis
- Batch analysis
- File upload
- Analysis history

## Components

### SingleAnalysis
- Text input for review
- Real-time sentiment analysis
- Sample reviews for quick testing
- Detailed results with confidence scores

### BatchAnalysis
- Multiple review inputs
- Add/remove review fields
- Bulk sentiment analysis
- Summary statistics

### FileUpload
- Drag & drop interface
- CSV/TSV file support
- Bulk processing
- Results preview

### StatsOverview
- Total analyses
- Positive/negative count
- Average confidence
- Real-time updates

### HistoryPanel
- Analysis history timeline
- Filter and search
- Clear history option

## Customization

### Colors (Neobrutalism Palette)
Edit `tailwind.config.js`:

```js
colors: {
  'neo-pink': '#FF6B9D',
  'neo-purple': '#C44569',
  'neo-blue': '#4E89FF',
  'neo-yellow': '#FFC947',
  'neo-green': '#00D9A3',
  'neo-orange': '#FF8A4C',
  'neo-red': '#FF4757',
}
```

### Box Shadows
```js
boxShadow: {
  'neo': '8px 8px 0px 0px rgba(0,0,0,1)',
  'neo-sm': '4px 4px 0px 0px rgba(0,0,0,1)',
  'neo-lg': '12px 12px 0px 0px rgba(0,0,0,1)',
}
```

## API Integration

The frontend connects to the FastAPI backend. Ensure the backend is running on `http://localhost:8000`.

API endpoints used:
- `POST /api/analyze` - Single review
- `POST /api/batch-analyze` - Multiple reviews
- `POST /api/upload` - File upload
- `GET /api/stats` - Statistics
- `GET /api/history` - History
- `DELETE /api/history` - Clear history
- `GET /health` - Health check

## Development Tips

1. **Hot Module Replacement (HMR)** is enabled for fast development
2. **ESLint** is configured for code quality
3. **Tailwind CSS** provides utility classes
4. **Framer Motion** handles all animations

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Troubleshooting

### API Connection Issues
- Verify backend is running on `http://localhost:8000`
- Check CORS settings in backend
- Verify API endpoint in `src/services/api.js`

### Build Issues
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Style Issues
```bash
# Rebuild Tailwind CSS
npm run build
```

## License

Part of the Sentiment Analysis Project - Group 4
