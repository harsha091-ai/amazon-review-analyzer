# 🤖 Amazon Review Sentiment Analysis - Full Stack Application

A complete full-stack AI-powered sentiment analysis platform for Amazon product reviews, featuring a FastAPI backend and React frontend with colorful Neobrutalism design.

![Status](https://img.shields.io/badge/status-active-success.svg)
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![React](https://img.shields.io/badge/react-18.2-blue.svg)

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Running the Application](#running-the-application)
- [API Documentation](#api-documentation)
- [Screenshots](#screenshots)
- [Team](#team)

## ✨ Features

### Backend (FastAPI)
- ✅ RESTful API with FastAPI
- ✅ Neural Network + TextBlob ensemble model
- ✅ Single & batch sentiment analysis
- ✅ CSV/TSV file upload and processing
- ✅ Analysis history tracking
- ✅ Real-time statistics
- ✅ CORS enabled for frontend
- ✅ Comprehensive error handling

### Frontend (React)
- ✅ Colorful Neobrutalism design
- ✅ Landing page with hero section
- ✅ Interactive dashboard
- ✅ Single review analysis
- ✅ Batch review processing
- ✅ Drag & drop file upload
- ✅ Analysis history viewer
- ✅ Real-time statistics
- ✅ Smooth animations (Framer Motion)
- ✅ Fully responsive

## 🛠 Tech Stack

### Backend
- **FastAPI** - Modern Python web framework
- **TensorFlow/Keras** - Neural network model
- **TextBlob** - NLP sentiment analysis
- **scikit-learn** - ML utilities
- **NLTK** - Text preprocessing
- **Pandas** - Data manipulation
- **Uvicorn** - ASGI server

### Frontend
- **React 18** - UI library
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **Axios** - HTTP client
- **React Router** - Navigation
- **React Dropzone** - File uploads

## 📁 Project Structure

```
Sentiment Analysis, Group 4/
├── backend/                    # FastAPI Backend
│   ├── main.py                # Main API application
│   ├── models.py              # Pydantic models
│   ├── ml_service.py          # ML service layer
│   ├── requirements.txt       # Python dependencies
│   ├── .env.example          # Environment template
│   └── README.md             # Backend documentation
│
├── frontend/                  # React Frontend
│   ├── src/
│   │   ├── components/       # React components
│   │   │   ├── SingleAnalysis.jsx
│   │   │   ├── BatchAnalysis.jsx
│   │   │   ├── FileUpload.jsx
│   │   │   ├── ResultCard.jsx
│   │   │   ├── StatsOverview.jsx
│   │   │   └── HistoryPanel.jsx
│   │   ├── pages/
│   │   │   ├── LandingPage.jsx
│   │   │   └── Dashboard.jsx
│   │   ├── services/
│   │   │   └── api.js        # API integration
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── README.md             # Frontend documentation
│
├── amazon2.tsv               # Dataset
├── sentiment_nn_model.h5     # Trained model
├── tfidf_vectorizer.pkl      # TF-IDF vectorizer
├── App.py                    # Original Streamlit app
└── README.md                 # This file
```

## 🚀 Installation

### Prerequisites
- Python 3.8 or higher
- Node.js 16 or higher
- npm or yarn

### Backend Setup

1. **Navigate to backend directory:**
```bash
cd backend
```

2. **Create virtual environment:**
```bash
python -m venv venv
```

3. **Activate virtual environment:**
```bash
# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

4. **Install dependencies:**
```bash
pip install -r requirements.txt
```

5. **Download NLTK data (first time only):**
```python
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"
```

### Frontend Setup

1. **Navigate to frontend directory:**
```bash
cd frontend
```

2. **Install dependencies:**
```bash
npm install
```

## ▶️ Running the Application

### Start Backend (Terminal 1)

```bash
cd backend
python main.py
```

Backend will run on: **http://localhost:8000**

API Documentation: **http://localhost:8000/docs**

### Start Frontend (Terminal 2)

```bash
cd frontend
npm run dev
```

Frontend will run on: **http://localhost:3000**

### Access the Application

1. **Landing Page:** http://localhost:3000
2. **Dashboard:** http://localhost:3000/dashboard
3. **API Docs:** http://localhost:8000/docs

## 📚 API Documentation

### Core Endpoints

#### Health Check
```bash
GET /health
```

#### Analyze Single Review
```bash
POST /api/analyze
Content-Type: application/json

{
  "review_text": "This product is amazing!"
}
```

#### Batch Analyze
```bash
POST /api/batch-analyze
Content-Type: application/json

{
  "reviews": [
    "Great product!",
    "Not satisfied",
    "Works well"
  ]
}
```

#### Upload File
```bash
POST /api/upload
Content-Type: multipart/form-data

file: <CSV or TSV file>
```

#### Get Statistics
```bash
GET /api/stats
```

#### Get History
```bash
GET /api/history?limit=10
```

#### Clear History
```bash
DELETE /api/history
```

### Interactive API Documentation

Visit **http://localhost:8000/docs** for Swagger UI with interactive API testing.

## 🎨 Design System

### Neobrutalism Theme

The frontend uses a bold, colorful Neobrutalism design with:

- **Thick black borders** (4px)
- **Bold shadows** (8px offset)
- **Vibrant colors:**
  - Pink: `#FF6B9D`
  - Purple: `#C44569`
  - Blue: `#4E89FF`
  - Yellow: `#FFC947`
  - Green: `#00D9A3`
  - Orange: `#FF8A4C`
  - Red: `#FF4757`

## 📊 Machine Learning Model

- **Architecture:** Neural Network (3 layers)
- **Features:** TF-IDF vectors (3000 features)
- **Accuracy:** 92%
- **Ensemble:** Neural Network + TextBlob
- **Input:** Text reviews
- **Output:** Sentiment (positive/negative), confidence, polarity, subjectivity

## 🧪 Testing the Application

### Test Single Review

1. Go to Dashboard
2. Click "Single Review" tab
3. Enter a review or use sample reviews
4. Click "Analyze Sentiment"
5. View detailed results

### Test Batch Analysis

1. Click "Batch Analysis" tab
2. Add multiple reviews
3. Click "Analyze All"
4. View summary and individual results

### Test File Upload

1. Click "File Upload" tab
2. Drag and drop a CSV/TSV file
3. View processing results
4. See preview of analyzed reviews

## 🔧 Configuration

### Backend Configuration

Edit `backend/.env`:

```env
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=True
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

### Frontend Configuration

Edit `frontend/src/services/api.js`:

```javascript
const API_BASE_URL = 'http://localhost:8000';
```

## 📦 Building for Production

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Frontend

```bash
cd frontend
npm run build
```

Serve the `dist/` directory with any static server.

## 🐛 Troubleshooting

### Backend Issues

**Issue:** Models not loading
```bash
# Ensure model files exist in parent directory:
# - sentiment_nn_model.h5
# - tfidf_vectorizer.pkl
```

**Issue:** NLTK data missing
```python
python -c "import nltk; nltk.download('all')"
```

### Frontend Issues

**Issue:** API connection failed
- Verify backend is running on port 8000
- Check CORS settings in backend
- Verify API_BASE_URL in `api.js`

**Issue:** Build errors
```bash
rm -rf node_modules package-lock.json
npm install
```

## 👥 Team

**Group 4 - Sentiment Analysis Project**

- **Smrithi** - Project setup and Analyzer
- **Kavimani** - Data collection, cleaning, and TextBlob labeling
- **Manishankar** - Univariate/Bivariate analysis
- **Kiranvel** - NLP feature exploration
- **Vaishnavi** - EDA summary insights and PPT
- **Saran** - Task building, deployment, and finalization
- **Abishek** - Final PPT and documentation
- **Akshara** - Best model building
- **Sushinth VS** - Model building evaluation (Accuracy, ROC AUC)

## 📄 License

This project is part of an academic group project.

## 🙏 Acknowledgments

- Amazon for the review dataset
- TensorFlow and TextBlob communities
- React and FastAPI communities

---

**Made with ❤️ by Group 4**

For issues or questions, please create an issue in the repository.
